public class Point {
    public Point(int r, int c) {
        this.r = r;
        this.c = c;
    }

    int r;
    int c;
}
